#!/usr/bin/perl -w
use strict;
package similarity;
use String::Approx 'adist';
my $minSub = 4; # minimum number of substitutions (included);

#http://search.cpan.org/~jhi/String-Approx-3.26/Approx.pm

sub getSimilaritiesMatrix
{
	my @inputs = @_;
	if ( ! (@inputs))   { die "NO INPUTS DEFINED"};
	if ( @inputs == 1 ) { die "ONLY 1 INPUT DEFINED"};

	my $dimensions = @inputs;

	my @results;
	for (my $row = 0; $row < $dimensions; $row++)
	{
		my @dist = adist($inputs[$row], @inputs);
		$results[$row] = \@dist;
	}

	my @answer = (0) x $dimensions;
	for (my $row = 0; $row < $dimensions; $row++)
	{
#		print "$inputs[$row] ";
		for (my $col = 0; $col < $dimensions; $col++)
		{
			if (($row != $col) && ($results[$row][$col] <= $minSub)) {$answer[$row]++; $answer[$col]++;  }; #print "ROW $row COL $col $inputs[$row] $inputs[$col] VALUE $results[$row][$col]\n"; };
		}
#		print "\n";
	}

#	for (my $k = 0; $k < $dimensions; $k++)
#	{
#		print "$k > $answer[$k]\t";
#		if ( ! ($k % 5)) { print "\n"; };
#	}

#	for (my $row = 0; $row < $dimensions; $row++)
#	{
#		print "$inputs[$row] ";
#		for (my $col = 0; $col < $dimensions; $col++)
#		{
#			print $results[$row][$col] . " "x10;
#		}
#		print "\n";
#	}
	return \@answer;
}














#http://search.cpan.org/~jhi/String-Approx-3.26/Approx.pm

#	my @inputs;
#	open FILE, "<resultset.txt" or die "couldnt";
#	while (<FILE>)
#	{
#		chomp;
#		push(@inputs, $_);
#	}

#	$dimensions = @inputs;

#	my @results;
#	for (my $row = 0; $row < $dimensions; $row++)
#	{
#		my @dist = adist($inputs[$row], @inputs);
#		$results[$row] = \@dist;
#	}

	#print " "x11 . join(" ", @inputs[0 .. ($dimensions-1)]) . "\n";

#	for (my $row = 0; $row < $dimensions; $row++)
#	{
		#print "$inputs[$row] ";
#		for (my $col = 0; $col < $dimensions; $col++)
#		{
			#print $results[$row][$col] . " "x10;
#		}
		#print "\n";
#	}
#	print "\n";



1;
