#!/usr/bin/perl -w
use strict;

my $input = $ARGV[0];
if ( ! (($input) && ( -f $input ))) { die "FILE EITHER NOT FOUND OR NOT EXISTENT\n"; };

my @dnaKey;
my %keyDna;
my @DIGIT_TO_CODE;
my %CODE_TO_DIGIT;
my %C_T_D;
my %D_T_C;
&loadVariables();


open INFILE,   "<$input"      or die "COULD NOT OPEN FILE $input: $!";
#open OUTFILE1, ">$input.out4" or die "COULD NOT OPEN FILE $input.out1: $!";
#open OUTFILE2, ">$input.out5" or die "COULD NOT OPEN FILE $input.out1: $!";
my $valid   = 0;
my $total   = 0;
my $skipped = 0;
my $nucIn   = 0;
my $nucOut  = 0;
my $nucSkip = 0;
while (my $line = <INFILE>)
{
	$total++;
	$nucIn  += length($line) -1;
	if ($line =~ /[N|n]/)
	{
		$skipped++;
		print "SKIPPED $line";
		$nucSkip += length($line);
		#skip;
	}
	elsif ($line =~ /([A|C|T|G]+)/)
	{
		my $originalSeq = $1;
		my $digit  = &dna2digit2($originalSeq);
		#my $recSeq = &digit2dna3($digit);
		#print OUTFILE1 "$digit\n";
		#print OUTFILE2 "$recSeq\n";
		#$nucOut += length($recSeq);
		$valid++;
	}
	else
	{
		die "INVALID LINE $line";
	}
}
#close OUTFILE2;
#close OUTFILE1;
close INFILE;

print "$valid out of $total ($skipped SKIPPED)\n";
print "IN: $nucIn OUT: $nucOut [" . (int(($nucOut/$nucIn)*100)) . "%] [$nucSkip]\n";





sub digit2dna3
{
	my $seq  = $_[0];
	my $lengthSeq = length($seq);
	my $outSeq;
# 	print "$seq (" . length($seq) . ") > ";
	my $extra = "";
	if ( $seq =~ /([^a|c|t|g|A|C|T|G]*)([a|c|t|g|A|C|T|G]*)/)
	{
		$seq   = $1;
		$extra = uc($2);
	}

	if ($lengthSeq != length("$seq$extra")) { die "ERROR UMPACKING DNA"; };

#	print "$seq (" . length($seq) . ") + $extra (" . length($extra) . ") >> ";

	for (my $s = 0; $s < length($seq); $s+=1)
	{
		my $subSeq  = substr($seq, $s, 1);
		$outSeq    .= $D_T_C{$subSeq};
	}

# 	print "$outSeq (" . length($outSeq) . ") -> ";
	$outSeq .= $extra;
# 	print "$outSeq (" . length($outSeq) . ")\n\n";
	return $outSeq;
}

sub dna2digit3
{
	my $input = uc($_[0]);
	my $extra = "";
	my $outPut;
# 	print "$input (" . length($input) . ") > ";
	while (length($input) % 3) { $extra = chop($input) . $extra; };

# 	print "$input (" . length($input) . ") + $extra (" . length($extra) . ")";

#   print "Seq: $input " . length($input) . "\n";
	$input =~ s/\r//g;
	$input =~ s/\n//g;

	for (my $i = 0; $i < length($input); $i+=3)
	{
		my $subInput = substr($input, $i, 3);
		$outPut     .= $C_T_D{$subInput};
	}

	if ($extra)
	{
		$outPut .= lc($extra);
	}
# 	print " >> $outPut (" . length($outPut) . ")\n";
# 	&digit2dna($outputHex);
# 	print "Dec: $outputDecStr " . length($outputDec) . "\n";
# 	print "Hex: $outputHexStr " . length($outputHex) . "\n";
	return $outPut;
}

#real	0m30.482s
#user	0m28.149s
#sys	0m0.321s

#real	0m15.182s 1 way no files
#user	0m14.390s
#sys	0m0.115s
#vs
#real	0m15.511s
#user	0m15.298s
#sys	0m0.038s




#30619547
#32268651
#1.649.104 1.57m
#FOR 1 MILLION 50BP SEQUENCES
#real	0m26.402s 2 ways
#user	0m26.250s
#sys	0m0.085s
#real	0m15.318s 1 way
#user	0m26.780s
#sys	0m0.109s
#real	0m14.362s 1 WAY NO FILES
#user	0m14.315s
#sys	0m0.028s


#30.8>12.1mb
#30.8>11.6mb = 2.65 (0.38) 2 ways
sub digit2dna2
{
	my $seq  = $_[0];
	my $lengthSeq = length($seq);
	my $outSeq;
# 	print "$seq (" . length($seq) . ") > ";
	my $extra = "";
	if ( $seq =~ /([^a|c|t|g|A|C|T|G]*)([a|c|t|g|A|C|T|G]*)/)
	{
		$seq   = $1;
		$extra = uc($2);
	}

	if ($lengthSeq != length("$seq$extra")) { die "ERROR UMPACKING DNA"; };

#	print "$seq (" . length($seq) . ") + $extra (" . length($extra) . ") >> ";

	for (my $s = 0; $s < length($seq); $s+=1)
	{
		my $subSeq  = substr($seq, $s, 1);
		$outSeq    .= $dnaKey[$CODE_TO_DIGIT{$subSeq}];
	}

# 	print "$outSeq (" . length($outSeq) . ") -> ";
	$outSeq .= $extra;
# 	print "$outSeq (" . length($outSeq) . ")\n\n";
	return $outSeq;
}

sub dna2digit2
{
	my $input = uc($_[0]);
	my $extra = "";
	my $outPut;
# 	print "$input (" . length($input) . ") > ";
	while (length($input) % 3) { $extra = chop($input) . $extra; };

# 	print "$input (" . length($input) . ") + $extra (" . length($extra) . ")";

#   print "Seq: $input " . length($input) . "\n";
	$input =~ s/\r//g;
	$input =~ s/\n//g;

	for (my $i = 0; $i < length($input); $i+=3)
	{
		my $subInput = substr($input, $i, 3);
		$outPut     .= $DIGIT_TO_CODE[$keyDna{$subInput}];
	}

	if ($extra)
	{
		$outPut .= lc($extra);
	}
# 	print " >> $outPut (" . length($outPut) . ")\n";
# 	&digit2dna($outputHex);
# 	print "Dec: $outputDecStr " . length($outputDec) . "\n";
# 	print "Hex: $outputHexStr " . length($outputHex) . "\n";
	return $outPut;
}




#real	2m13.232s 2 WAYS
#user	2m12.576s
#sys	0m0.383s
#real	1m17.088s 1 WAY
#user	1m16.609s
#sys	0m0.300s
#real	1m15.519s 1 WAY NO FILE
#user	1m15.394s
#sys	0m0.069s

#30.8>16.6
sub digit2dna
{
	my $seq       = $_[0];

# 	print "$seq (" . length($seq) . ") > ";
	my $extra = "";
	if ( $seq =~ /([[:^lower:]]*)([[:lower:]]+)/)
	{
		$seq   = $1;
		$extra = uc($2);
	}
# 	print "$seq (" . length($seq) . ") + $extra (" . length($extra) . ") >> ";

	my $BASE = 4;
	my @str_digits;
	for (my $s = 0; $s < length($seq); $s+=2)
	{
		my $subSeq  = substr($seq, $s, 2);
		my $subs    = 0;

		$subSeq     = hex($subSeq);
		my @digits  = (0) x 4; # cria o array @digits composto de 4 zeros

		my $i = 0; 
# 		print "$subSeq\t";
		while ($subSeq) { # loop para decompor o numero
				$digits[4 - ++$i] = $subSeq % $BASE;
				$subSeq = int ($subSeq / $BASE);
		}
# 		print "@digits\t"; # imprime o codigo ascII transformado em base 4
		my $subJoin = join("", @digits);
		$subJoin =~ tr/0123/ACGT/;
# 		print "$subJoin\n"; # imprime o codigo ascII transformado em base 4
		push @str_digits, $subJoin;    # salva todos os codigos ascII em base
										# 4 gerados no array. cada elemento deste
									    # array ser� um outro array de 4 elementos..
	}
	my $join = join("", @str_digits);
# 	print "$join (" . length($join) . ") -> ";
	$join .= $extra;
# 	print "$join (" . length($join) . ")\n\n";
	return $join;
# 	print "Hex: $seq  " . length($seq)      . "\n";
# 	print "Seq: $join " . length($sequence) . "\n";
}

sub dna2digit
{
	my $input = uc($_[0]);
	my $extra = "";
# 	print "$input (" . length($input) . ") > ";
	while (length($input) % 4) { $extra = chop($input) . $extra; };

# 	print "$input (" . length($input) . ") + $extra (" . length($extra) . ")";

#     print "Seq: $input " . length($input) . "\n";
	$input =~ s/\r//g;
	$input =~ s/\n//g;
	$input =~ tr/ACGTacgt/01230123/;
# 	print "Inp: $input "    . length($input)    . "\n";
	my $outputHex; my $outputHexStr;
	my $outputDec; my $outputDecStr;

	for (my $i = 0; $i < length($input); $i+=4)
	{
		my $subInput = substr($input, $i, 4);
		#print "$i - $subInput\n";
# 		my $subInputDec = $subInput;
		my $subInputHex = $subInput;

		$subInputHex =~ s/(.)(.)(.)(.)/(64*$1)+(16*$2)+(4*$3)+$4/gex;
# 		$subInputDec =~ s/(.)(.)(.)(.)/(64*$1)+(16*$2)+(4*$3)+$4/gex;

		$subInputHex = sprintf("%X", $subInputHex);
		if (length($subInputHex) <   2) {$subInputHex = "0$subInputHex"; };
# 		if ($subInputDec         < 100) {$outputDecStr .= "_" ; };

		$outputHex    .= $subInputHex;
# 		$outputHexStr .= "__" . $subInputHex;
# 
# 		$outputDec    .= $subInputDec;
# 		$outputDecStr .= "_" . $subInputDec;
	}
	if ($extra)
	{
		$outputHex .= lc($extra);
	}
# 	print " >> $outputHex (" . length($outputHex) . ")\n";
# 	&digit2dna($outputHex);
# 	print "Dec: $outputDecStr " . length($outputDec) . "\n";
# 	print "Hex: $outputHexStr " . length($outputHex) . "\n";
	return $outputHex;
}






sub loadVariables
{


	foreach my $st ("A", "C", "G", "T")
	{
	foreach my $nd ("A", "C", "G", "T")
	{
	foreach my $rd ("A", "C", "G", "T")
	{
		push(@dnaKey, "$st$nd$rd");
	}
	}
	}

	@DIGIT_TO_CODE = qw (0 1 2 3 4 5 6 7 8 9 b d e f h i j k l m n o p q r s u v w x y z B D E F H I J K L M N O P Q R S U V W X Y Z / - = + ] [ : > < . ? );
	#  COUNT             1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 
	#                    1                 10                  20        25        30        35        40  42              50                  60        65
	#  INDEX             0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 
	#                    0                   10                  20        25        30        35        40  42              50                  60      64
	for (my $k = 0; $k < @dnaKey; $k++)
	{
		$keyDna{$dnaKey[$k]} = $k;
	}

	for (my $i = 0; $i < @DIGIT_TO_CODE; $i++)
	{
		$CODE_TO_DIGIT{$DIGIT_TO_CODE[$i]} = $i;
	}

	

	$C_T_D{"AAA"} = "0";
	$C_T_D{"AAC"} = "1";
	$C_T_D{"AAG"} = "2";
	$C_T_D{"AAT"} = "3";
	$C_T_D{"ACA"} = "4";
	$C_T_D{"ACC"} = "5";
	$C_T_D{"ACG"} = "6";
	$C_T_D{"ACT"} = "7";
	$C_T_D{"AGA"} = "8";
	$C_T_D{"AGC"} = "9";
	$C_T_D{"AGG"} = "b";
	$C_T_D{"AGT"} = "d";
	$C_T_D{"ATA"} = "e";
	$C_T_D{"ATC"} = "f";
	$C_T_D{"ATG"} = "h";
	$C_T_D{"ATT"} = "i";

	$C_T_D{"CAA"} = "j";
	$C_T_D{"CAC"} = "k";
	$C_T_D{"CAG"} = "l";
	$C_T_D{"CAT"} = "m";
	$C_T_D{"CCA"} = "n";
	$C_T_D{"CCC"} = "o";
	$C_T_D{"CCG"} = "p";
	$C_T_D{"CCT"} = "q";
	$C_T_D{"CGA"} = "r";
	$C_T_D{"CGC"} = "s";
	$C_T_D{"CGG"} = "u";
	$C_T_D{"CGT"} = "v";
	$C_T_D{"CTA"} = "w";
	$C_T_D{"CTC"} = "x";
	$C_T_D{"CTG"} = "y";
	$C_T_D{"CTT"} = "z";

	$C_T_D{"GAA"} = "B";
	$C_T_D{"GAC"} = "D";
	$C_T_D{"GAG"} = "E";
	$C_T_D{"GAT"} = "F";
	$C_T_D{"GCA"} = "H";
	$C_T_D{"GCC"} = "I";
	$C_T_D{"GCG"} = "J";
	$C_T_D{"GCT"} = "K";
	$C_T_D{"GGA"} = "L";
	$C_T_D{"GGC"} = "M";
	$C_T_D{"GGG"} = "N";
	$C_T_D{"GGT"} = "O";
	$C_T_D{"GTA"} = "P";
	$C_T_D{"GTC"} = "Q";
	$C_T_D{"GTG"} = "R";
	$C_T_D{"GTT"} = "S";

	$C_T_D{"TAA"} = "U";
	$C_T_D{"TAC"} = "V";
	$C_T_D{"TAG"} = "W";
	$C_T_D{"TAT"} = "X";
	$C_T_D{"TCA"} = "Y";
	$C_T_D{"TCC"} = "Z";
	$C_T_D{"TCG"} = "@";
	$C_T_D{"TCT"} = "#";
	$C_T_D{"TGA"} = "%";
	$C_T_D{"TGC"} = "&";
	$C_T_D{"TGG"} = "*";
	$C_T_D{"TGT"} = "(";
	$C_T_D{"TTA"} = ")";
	$C_T_D{"TTC"} = "-";
	$C_T_D{"TTG"} = "+";
	$C_T_D{"TTT"} = "=";

	foreach my $key (keys %C_T_D)
	{
		$D_T_C{$C_T_D{$key}} = $key;
	}

}

1;
