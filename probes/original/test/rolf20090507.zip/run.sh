#!/bin/sh
echo "::::::::::::::::::::::::::::::::::::::::"
echo "RUNNING OVER 39 FILES:"
echo "	Bovine_papillomavirus_type_1_complete_genome.fasta"
echo "	Bovine_papillomavirus_type_2_complete_genome.fasta"
echo "	Candida_albicans_sc5314_CONTIGS.fasta"
echo "	Candida_albicans_wo1_CONTIGS.fasta"
echo "	Candida_glabrata_CBS138_CHROMOSSOMES.fasta"
echo "	Deer_papillomavirus_complete_genome.fasta"
echo "	European_elk_papillomavirus_complete_genome.fasta"
echo "	HUMAN_CELLULAR_DNA_HUMAN_PAPILLOMA_VIRUS_TYPE_68_PROVIRAL_DNA.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_ORF_E6_ORF_E7_ORF_E1_ORF_E2_ORF_E4_ORF.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_10_HPV10_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_11_HPV11_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_12_HPV12_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_13_HPV13_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_16_HPV16_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_18_HPV18_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_26_HPV26_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_31_HPV31A_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_33_HPV33_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_35H_HPV35H_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_35_HPV35_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_39_HPV39_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_40_HPV40_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_44_HPV44_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_45_HPV45_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_51_HPV51_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_52_HPV52_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_53_HPV53_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_54_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_56_HPV56_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_59_COMPLETE_VIRAL_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_61_HPV61_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_66_HPV66_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_6B_HPV6B_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_70_COMPLETE_GENOME.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_72_E6_E7_E1A_E1B_E2_E4_L2_AND_L1.fasta"
echo "	HUMAN_PAPILLOMA_VIRUS_TYPE_73_E6_E7_E1_E2_E4_L2_AND_L1_GENES.fasta"
echo "	Ovine_papillomavirus_1_complete_genome.fasta"
echo "	Ursus_maritimus_papillomavirus_type_1_complete_genome.fasta"
echo "	Western_roedeer_papillomavirus_1_complete_genome.fasta"
echo "::::::::::::::::::::::::::::::::::::::::

"

echo "...................."
echo "OPTIMIZING"
echo "...................."
time sudo mysql -u probe < /home/saulo/Desktop/rolf/sql/probe_6_optimize.sql

echo "####################"
echo "RUNNING FILE 1 OUT OF 39	Bovine_papillomavirus_type_1_complete_genome.fasta"
echo "####################"
time ./probe_extractor.pl input Bovine_papillomavirus_type_1_complete_genome.fasta 10559 0 5 
echo "********************"
echo "FINISH RUNNING FILE 1 OUT OF 39	Bovine_papillomavirus_type_1_complete_genome.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 2 OUT OF 39	Bovine_papillomavirus_type_2_complete_genome.fasta"
echo "####################"
time ./probe_extractor.pl input Bovine_papillomavirus_type_2_complete_genome.fasta 10560 0 5 
echo "********************"
echo "FINISH RUNNING FILE 2 OUT OF 39	Bovine_papillomavirus_type_2_complete_genome.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 3 OUT OF 39	Candida_albicans_sc5314_CONTIGS.fasta"
echo "####################"
time ./probe_extractor.pl input Candida_albicans_sc5314_CONTIGS.fasta 237561 0 4 
echo "********************"
echo "FINISH RUNNING FILE 3 OUT OF 39	Candida_albicans_sc5314_CONTIGS.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 4 OUT OF 39	Candida_albicans_wo1_CONTIGS.fasta"
echo "####################"
time ./probe_extractor.pl input Candida_albicans_wo1_CONTIGS.fasta 294748 0 4 
echo "********************"
echo "FINISH RUNNING FILE 4 OUT OF 39	Candida_albicans_wo1_CONTIGS.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 5 OUT OF 39	Candida_glabrata_CBS138_CHROMOSSOMES.fasta"
echo "####################"
time ./probe_extractor.pl input Candida_glabrata_CBS138_CHROMOSSOMES.fasta 284593 0 2 
echo "********************"
echo "FINISH RUNNING FILE 5 OUT OF 39	Candida_glabrata_CBS138_CHROMOSSOMES.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 6 OUT OF 39	Deer_papillomavirus_complete_genome.fasta"
echo "####################"
time ./probe_extractor.pl input Deer_papillomavirus_complete_genome.fasta 10564 0 5 
echo "********************"
echo "FINISH RUNNING FILE 6 OUT OF 39	Deer_papillomavirus_complete_genome.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 7 OUT OF 39	European_elk_papillomavirus_complete_genome.fasta"
echo "####################"
time ./probe_extractor.pl input European_elk_papillomavirus_complete_genome.fasta 10565 0 5 
echo "********************"
echo "FINISH RUNNING FILE 7 OUT OF 39	European_elk_papillomavirus_complete_genome.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 8 OUT OF 39	HUMAN_CELLULAR_DNA_HUMAN_PAPILLOMA_VIRUS_TYPE_68_PROVIRAL_DNA.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_CELLULAR_DNA_HUMAN_PAPILLOMA_VIRUS_TYPE_68_PROVIRAL_DNA.fasta 45240 0 2 
echo "********************"
echo "FINISH RUNNING FILE 8 OUT OF 39	HUMAN_CELLULAR_DNA_HUMAN_PAPILLOMA_VIRUS_TYPE_68_PROVIRAL_DNA.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 9 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_ORF_E6_ORF_E7_ORF_E1_ORF_E2_ORF_E4_ORF.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_ORF_E6_ORF_E7_ORF_E1_ORF_E2_ORF_E4_ORF.fasta 10566 0 8 
echo "********************"
echo "FINISH RUNNING FILE 9 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_ORF_E6_ORF_E7_ORF_E1_ORF_E2_ORF_E4_ORF.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 10 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_10_HPV10_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_10_HPV10_COMPLETE_GENOME.fasta 333759 0 5 
echo "********************"
echo "FINISH RUNNING FILE 10 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_10_HPV10_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 11 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_11_HPV11_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_11_HPV11_COMPLETE_GENOME.fasta 10580 0 5 
echo "********************"
echo "FINISH RUNNING FILE 11 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_11_HPV11_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 12 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_12_HPV12_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_12_HPV12_COMPLETE_GENOME.fasta 10604 0 5 
echo "********************"
echo "FINISH RUNNING FILE 12 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_12_HPV12_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 13 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_13_HPV13_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_13_HPV13_COMPLETE_GENOME.fasta 10573 0 5 
echo "********************"
echo "FINISH RUNNING FILE 13 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_13_HPV13_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 14 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_16_HPV16_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_16_HPV16_COMPLETE_GENOME.fasta 333760 0 5 
echo "********************"
echo "FINISH RUNNING FILE 14 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_16_HPV16_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 15 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_18_HPV18_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_18_HPV18_COMPLETE_GENOME.fasta 333761 0 5 
echo "********************"
echo "FINISH RUNNING FILE 15 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_18_HPV18_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 16 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_26_HPV26_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_26_HPV26_COMPLETE_GENOME.fasta 333762 0 5 
echo "********************"
echo "FINISH RUNNING FILE 16 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_26_HPV26_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 17 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_31_HPV31A_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_31_HPV31A_COMPLETE_GENOME.fasta 10585 0 5 
echo "********************"
echo "FINISH RUNNING FILE 17 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_31_HPV31A_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 18 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_33_HPV33_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_33_HPV33_COMPLETE_GENOME.fasta 10586 0 5 
echo "********************"
echo "FINISH RUNNING FILE 18 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_33_HPV33_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 19 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_35H_HPV35H_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_35H_HPV35H_COMPLETE_GENOME.fasta 31551 0 5 
echo "********************"
echo "FINISH RUNNING FILE 19 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_35H_HPV35H_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 20 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_35_HPV35_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_35_HPV35_COMPLETE_GENOME.fasta 10587 0 5 
echo "********************"
echo "FINISH RUNNING FILE 20 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_35_HPV35_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 21 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_39_HPV39_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_39_HPV39_COMPLETE_GENOME.fasta 10588 0 5 
echo "********************"
echo "FINISH RUNNING FILE 21 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_39_HPV39_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 22 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_40_HPV40_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_40_HPV40_COMPLETE_GENOME.fasta 10615 0 5 
echo "********************"
echo "FINISH RUNNING FILE 22 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_40_HPV40_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 23 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_44_HPV44_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_44_HPV44_COMPLETE_GENOME.fasta 10592 0 5 
echo "********************"
echo "FINISH RUNNING FILE 23 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_44_HPV44_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 24 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_45_HPV45_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_45_HPV45_COMPLETE_GENOME.fasta 10593 0 5 
echo "********************"
echo "FINISH RUNNING FILE 24 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_45_HPV45_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 25 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_51_HPV51_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_51_HPV51_COMPLETE_GENOME.fasta 10595 0 5 
echo "********************"
echo "FINISH RUNNING FILE 25 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_51_HPV51_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 26 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_52_HPV52_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_52_HPV52_COMPLETE_GENOME.fasta 10618 0 5 
echo "********************"
echo "FINISH RUNNING FILE 26 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_52_HPV52_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 27 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_53_HPV53_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_53_HPV53_COMPLETE_GENOME.fasta 333765 0 5 
echo "********************"
echo "FINISH RUNNING FILE 27 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_53_HPV53_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 28 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_54_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_54_COMPLETE_GENOME.fasta 333766 0 5 
echo "********************"
echo "FINISH RUNNING FILE 28 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_54_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 29 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_56_HPV56_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_56_HPV56_COMPLETE_GENOME.fasta 10596 0 5 
echo "********************"
echo "FINISH RUNNING FILE 29 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_56_HPV56_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 30 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_59_COMPLETE_VIRAL_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_59_COMPLETE_VIRAL_GENOME.fasta 37115 0 5 
echo "********************"
echo "FINISH RUNNING FILE 30 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_59_COMPLETE_VIRAL_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 31 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_61_HPV61_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_61_HPV61_COMPLETE_GENOME.fasta 37116 0 5 
echo "********************"
echo "FINISH RUNNING FILE 31 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_61_HPV61_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 32 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_66_HPV66_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_66_HPV66_COMPLETE_GENOME.fasta 37119 0 5 
echo "********************"
echo "FINISH RUNNING FILE 32 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_66_HPV66_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 33 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_6B_HPV6B_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_6B_HPV6B_COMPLETE_GENOME.fasta 10600 0 5 
echo "********************"
echo "FINISH RUNNING FILE 33 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_6B_HPV6B_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 34 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_70_COMPLETE_GENOME.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_70_COMPLETE_GENOME.fasta 39457 0 5 
echo "********************"
echo "FINISH RUNNING FILE 34 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_70_COMPLETE_GENOME.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 35 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_72_E6_E7_E1A_E1B_E2_E4_L2_AND_L1.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_72_E6_E7_E1A_E1B_E2_E4_L2_AND_L1.fasta 333770 0 8 
echo "********************"
echo "FINISH RUNNING FILE 35 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_72_E6_E7_E1A_E1B_E2_E4_L2_AND_L1.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 36 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_73_E6_E7_E1_E2_E4_L2_AND_L1_GENES.fasta"
echo "####################"
time ./probe_extractor.pl input HUMAN_PAPILLOMA_VIRUS_TYPE_73_E6_E7_E1_E2_E4_L2_AND_L1_GENES.fasta 51033 0 8 
echo "********************"
echo "FINISH RUNNING FILE 36 OUT OF 39	HUMAN_PAPILLOMA_VIRUS_TYPE_73_E6_E7_E1_E2_E4_L2_AND_L1_GENES.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 37 OUT OF 39	Ovine_papillomavirus_1_complete_genome.fasta"
echo "####################"
time ./probe_extractor.pl input Ovine_papillomavirus_1_complete_genome.fasta 56144 0 5 
echo "********************"
echo "FINISH RUNNING FILE 37 OUT OF 39	Ovine_papillomavirus_1_complete_genome.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 38 OUT OF 39	Ursus_maritimus_papillomavirus_type_1_complete_genome.fasta"
echo "####################"
time ./probe_extractor.pl input Ursus_maritimus_papillomavirus_type_1_complete_genome.fasta 461322 0 5 
echo "********************"
echo "FINISH RUNNING FILE 38 OUT OF 39	Ursus_maritimus_papillomavirus_type_1_complete_genome.fasta"
echo "********************


"


echo "####################"
echo "RUNNING FILE 39 OUT OF 39	Western_roedeer_papillomavirus_1_complete_genome.fasta"
echo "####################"
time ./probe_extractor.pl input Western_roedeer_papillomavirus_1_complete_genome.fasta 470214 0 5 
echo "********************"
echo "FINISH RUNNING FILE 39 OUT OF 39	Western_roedeer_papillomavirus_1_complete_genome.fasta"
echo "********************


"


echo "...................."
echo "OPTIMIZING"
echo "...................."
time sudo mysql -u probe < /home/saulo/Desktop/rolf/sql/probe_6_optimize.sql

