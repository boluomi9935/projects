USE probe;

DROP TABLE probe.fast;
DROP TABLE probe.coordinates;
DROP TABLE probe.probe;
DROP TABLE probe.organism;



