sudo mysql -u root --password=cbscbs12 < /home/saulo/Desktop/rolf/sql/probe_1_users.sql
sudo mysql -u probe < /home/saulo/Desktop/rolf/sql/probe_2_create.sql
sudo mysql -u probe < /home/saulo/Desktop/rolf/sql/probe_4_ADD.sql

