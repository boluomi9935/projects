USE probe;
INSERT INTO `probe`.`sequenceType` VALUES (1, 'CDS');
INSERT INTO `probe`.`sequenceType` VALUES (2, 'CHROMOSSOMES');
INSERT INTO `probe`.`sequenceType` VALUES (3, 'CIRCULAR');
INSERT INTO `probe`.`sequenceType` VALUES (4, 'CONTIGS');
INSERT INTO `probe`.`sequenceType` VALUES (5, 'COMPLETE');
INSERT INTO `probe`.`sequenceType` VALUES (6, 'GENES');
INSERT INTO `probe`.`sequenceType` VALUES (7, 'ORF');
INSERT INTO `probe`.`sequenceType` VALUES (8, 'PARTIAL');
INSERT INTO `probe`.`sequenceType` VALUES (9, 'WGS SCAFFOLD');

