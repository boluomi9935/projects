USE probe;
OPTIMIZE TABLE probe.organism;
OPTIMIZE TABLE probe.probe;
OPTIMIZE TABLE probe.coordinates;


